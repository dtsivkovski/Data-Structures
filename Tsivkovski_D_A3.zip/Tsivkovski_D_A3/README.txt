Name: Daniel Tsivkovski
Email: tsivkovski@chapman.edu
Course: CPSC350-03
ID: 2456881
Assignment 3
-----
Submitted Files:
- Monostack.h
- Monostack.tpp
- main.cpp
- SpeakerView.h
- SpeakerView.cpp
-----
References:
- C++ Template Classes - https://www.learncpp.com/cpp-tutorial/template-classes/
- Reset File to Beginning - https://en.cppreference.com/w/cpp/io/basic_istream/seekg
----- 
How to run:
- Compile in the docker container using: `g++ *.cpp`
- Use the first command line argument (after ./a.out) to specify the input file.
    - Ex: "./a.out sampleInput.txt"
