Name: Daniel Tsivkovski , collaborated with Joey Shoda
Email: tsivkovski@chapman.edu
Course: CPSC350-03
Assignment 2
-----
Submitted Files:
- Boss.h
- Boss.cpp
- Enemy.h
- Enemy.cpp
- Game.h
- Game.cpp
- main.cpp
- Mario.h
- Mario.cpp
- WarpPipe.h
- WarpPipe.cpp
- World.h
- World.cpp

-----
References: No references used
----- 
How to run:
- Compile in the docker container using: `g++ *.cpp`
- Run the code using `./a.out inputFile outputFile`
    - The argument `inputFile` should be replaced with the name of the inputFile where your arguments for the game exist
    - The argument `outputFile` should be replaced with the name of the output file to display the game's text output to.
